public class student {
    public void sayHello(){
    //TODO: Implement this function   
    System.out.println("I u18108478 am a COS212 student. I pinky promise that I will work hard in this module and not cheat!!!");
    }
}
