public class student {
    public void sayHello(){
    //TODO: Implement this function    
    }
}
