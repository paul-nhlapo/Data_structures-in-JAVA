public class main {
    public static void main(String[] args) {
        student std = new student();
        std.sayHello();
    }
}
