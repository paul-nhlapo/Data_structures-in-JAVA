public class SelectionSort extends Sorting {
    
    public SelectionSort(){
    }

    @Override
    public String[] sortAcs(Vertex[] array) {
        
    }

    @Override
    public String[] sortDsc(Vertex[] array) {
        
    }
}
