public class InsertSort extends Sorting {

    public InsertSort(){
    }

    @Override
    public String[] sortAcs(Vertex[] array) {
       
    }

    @Override
    public String[] sortDsc(Vertex[] array) {
        
    }
}
