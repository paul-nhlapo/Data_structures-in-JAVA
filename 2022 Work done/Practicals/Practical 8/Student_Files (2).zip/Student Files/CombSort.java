public class CombSort extends Sorting {
    public CombSort(){
    }

    @Override
    public String[] sortAcs(Vertex[] array) {
        
    }

    @Override
    public String[] sortDsc(Vertex[] array) {
        
    }
}
