public class BubbleSort extends Sorting {
    public BubbleSort(){
    }

    @Override
    public String[] sortAcs(Vertex[] array) {
        
    }

    @Override
    public String[] sortDsc(Vertex[] array) {
        
    }
}
