

@SuppressWarnings("unchecked")
public class MinHeap<T extends Comparable<T>> extends Heap<T> {

    public MinHeap(int capacity) {
	super(capacity);
    }

    ////// You may not change any code above this line //////

    ////// Implement the functions below this line //////

    @Override
    public void insert(T elem) {

        //Your code goes here
    }

    public T removeMin() {

        //Your code goes here
    }

    public void delete(T elem) {

	//Your code goes here
    }


    //Helper functions


}