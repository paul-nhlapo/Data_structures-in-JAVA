
@SuppressWarnings("unchecked")
public class MaxHeap<T extends Comparable<T>> extends Heap<T> {

    public MaxHeap(int capacity) {
	super(capacity);
    }

    ////// You may not change any code above this line //////

    ////// Implement the functions below this line ////// 

    @Override
    public void insert(T elem) {

        //Your code goes here
    }

    public T removeMax() {

        //Your code goes here
    }

    public void delete(T elem) {

	//Your code goes here
    }


    //Helper functions


}