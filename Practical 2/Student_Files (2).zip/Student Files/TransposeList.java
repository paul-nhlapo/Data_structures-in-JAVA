public class TransposeList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        //TODO: Implement the function
    }

    @Override
    public void access(T data) {
        //TODO: Implement the function
    }
}
