public class NaturalOrderList<T extends Comparable<T>> extends SelfOrderingList<T> {
    @Override
    public SelfOrderingList<T> getBlankList() {
        //TODO: Implement the function
    }

    @Override
    public void access(T data) {
        
    }

    @Override
    public void insert(T data) {
        //TODO: Implement the function
    }
}
