public class List<T> {
    public int length;
    public Node<T> head;

    public List() {
    }

    public String toString() {
        return "";
    }

    public void append(T val) {
    }

    public boolean remove(T val) {
        return false;
    }

    public boolean remove(List<T> val) {
        return false;
    }

    public boolean contains(T search) {
        return false;
    }

    public boolean equals(List<T> other) {
        return false;
    }
}
