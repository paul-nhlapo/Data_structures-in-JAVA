public class Node<T extends Comparable<T>> {

	Comparable<T>[] keys;
	Node<T>[] children;
	boolean leaf;
	int keyTally;
	int m;

	/**
	 * 
	 * @param m
	 */
	@SuppressWarnings("unchecked")
	public Node(int m) {
		// TODO - implement Node.Node
		keys = new Comparable[m - 1];
		children = new Node[m];
		leaf = true;
		keyTally = 1;

		for (int i = 0; i < m; i++)
			children[i] = null;

	}

	// Initialize a node with a key
	Node(T key) {
		keys[0] = key;
	}

	@Override
	public String toString() {
		String res = "[";
		for (int i = 0; i < keys.length; i++) {
			if (keys[i] != null)
				res += keys[i];
			else
				res += "null";
			res += ",";
		}
		if (res.length() > 1) {
			res = res.substring(0, res.length() - 1);
		}
		return res + "]";
	}

	public void splitChild(int i, Node<T> root) {
		Node<T> z = new Node<T>(m);
		Node<T> y = root.children[i];
		z.leaf = y.leaf;
		// The key that will be moved to the parent during splitting can
		// be determined as follows pos = (m-1)/2
		z.keyTally = m / 2;
		for (int j = 0; j < m / 2; j++) {
			z.keys[j] = y.keys[j + m / 2];
		}
		if (!y.leaf) {
			for (int j = 0; j < m / 2; j++) {
				z.children[j] = y.children[j + m / 2];
			}
		}
		y.keyTally = m / 2;
		for (int j = root.keyTally; j >= i + 1; j--) {
			root.children[j + 1] = root.children[j];
		}
		root.children[i + 1] = z;
		for (int j = root.keyTally - 1; j >= i; j--) {
			root.keys[j + 1] = root.keys[j];
		}
		root.keys[i] = y.keys[m / 2];
		root.keyTally = root.keyTally + 1;
	}

	public void insertNonFull(T data) {
		int i = keyTally - 1;
		if (leaf == true) {
			while (i >= 0 && keys[i].compareTo(data) > 0) {
				keys[i + 1] = keys[i];
				i--;
			}
		}

		keys[i + 1] = data;

	}

	public int countNumKeys() {

		int count = 0;
		for (int i = 0; i < keys.length; i++) {
			if (keys[i] != null) {
				count++;
			}
		}
		return count;
	}

	public int countNumNodes() {

		// Count all nodes in the tree including the root
		int count = 0;
		for (int i = 0; i < children.length; i++) {
			if (children[i] != null) {
				count++;
			}
		}
		return count;

	}

	public void fillArray(Node<T>[] nodes, int i) {
		// TODO - implement Node.fillArray

		if (this != null) {
			nodes[i] = this;
			i++;
			for (int j = 0; j < children.length; j++) {
				if (children[j] != null) {
					children[j].fillArray(nodes, i);
				}
			}
		}

    }


	
}