public class BTree<T extends Comparable<T>> {

	private int m;
	private Node<T> root;

	/**
	 * 
	 * @param m
	 */
	public BTree(int m) {
		// TODO - implement BTree.BTree
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param data
	 */
	public Node<T> insert(T data) {
		// TODO - implement BTree.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param data
	 */
	public Node<T> find(T data) {
		// TODO - implement BTree.find
		throw new UnsupportedOperationException();
	}

	public Node<T>[] nodes() {
		// TODO - implement BTree.leaves
		throw new UnsupportedOperationException();
	}

	public int numKeys() {
		// TODO - implement BTree.numKeys
		throw new UnsupportedOperationException();
	}

	public int countNumNodes() {
		// TODO - implement BTree.countNumLeaves
		throw new UnsupportedOperationException();
	}

}