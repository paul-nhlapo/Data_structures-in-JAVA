public class Graph {
    public Vertex[] vertices = new Vertex[0];
    // This is an array used to store the vertices.
    // The array will always be sorted alphabetically.
    // The array will always be the correct size (i.e. there are no empty spaces)

    public Edge[] edges = new Edge[0];
    // This is an array used to store the edges.
    // The array will always be sorted using Edge.compareTo().
    // The array will always be the correct size (i.e. there are no empty spaces)

    public void addVertex(String v) {

        // Check if the vertex already exists in the graph.
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].name.equals(v)) {
                return;
            }
        }

        if (vertices.length == 0) {
            vertices = new Vertex[1];
            vertices[0] = new Vertex(v);
        } else {
            Vertex[] temp = new Vertex[vertices.length + 1];
            for (int i = 0; i < vertices.length; i++) {
                temp[i] = vertices[i];
            }
            temp[temp.length - 1] = new Vertex(v);
            vertices = temp;
        }

        // Sort the vertices array alphabetically by the vertex name.
        for (int i = 0; i < vertices.length; i++) {
            for (int j = 0; j < vertices.length - i - 1; j++) {
                if (vertices[j].name.compareTo(vertices[j + 1].name) > 0) {
                    Vertex temp = vertices[j];
                    vertices[j] = vertices[j + 1];
                    vertices[j + 1] = temp;
                }
            }
        }

    }

    public void removeVertex(String v) {
        // Find the index of the vertex to be removed
        int indexToRemove = -1;
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].name.equals(v)) {
                indexToRemove = i;
                break;
            }
        }

        // If the vertex is not found, do nothing
        if (indexToRemove == -1) {
            return;
        }

        // Create a new vertices array with reduced size
        Vertex[] newVertices = new Vertex[vertices.length - 1];
        int newIndex = 0;

        // Copy vertices except for the one being removed
        for (int i = 0; i < vertices.length; i++) {
            if (i != indexToRemove) {
                newVertices[newIndex] = vertices[i];
                newIndex++;
            }
        }

        // Update the vertices array
        vertices = newVertices;

        // Remove any edges connected to the removed vertex
        removeEdgesWithVertex(v);
    }

    private void removeEdgesWithVertex(String v) {
        // Create a new edges array with reduced size
        Edge[] newEdges = new Edge[edges.length];
        int newIndex = 0;

        // Copy edges except for the ones connected to the removed vertex
        for (Edge edge : edges) {
            if (!(edge.vertexA.name.equals(v) || edge.vertexB.name.equals(v))) {
                newEdges[newIndex] = edge;
                newIndex++;
            }
        }

        // Update the edges array
        edges = new Edge[newIndex];
        for (int i = 0; i < newIndex; i++) {
            edges[i] = newEdges[i];
        }

    }

    public void addEdge(String a, String b, int w) {
        // Check if the vertices exist in the graph
        Vertex vertexA = null;
        Vertex vertexB = null;
        for (Vertex vertex : vertices) {
            if (vertex.name.equals(a)) {
                vertexA = vertex;
            }
            if (vertex.name.equals(b)) {
                vertexB = vertex;
            }
        }

        // If either vertex is missing, do nothing
        if (vertexA == null || vertexB == null) {
            return;
        }

        // Check if the edge already exists in the graph
        for (Edge edge : edges) {
            if ((edge.vertexA == vertexA && edge.vertexB == vertexB) ||
                    (edge.vertexA == vertexB && edge.vertexB == vertexA)) {
                return;
            }
        }

        // Create the new edge and update the edges array
        Edge newEdge = new Edge(vertexA, vertexB, w);
        // Edge[] newEdges = Arrays.copyOf(edges, edges.length + 1);
        Edge[] newEdges = new Edge[edges.length + 1];
        for (int i = 0; i < edges.length; i++) {
            newEdges[i] = edges[i];
        }

        newEdges[newEdges.length - 1] = newEdge;
        // Sort the newEdges array using bubble sort
        for (int i = 0; i < newEdges.length - 1; i++) {
            for (int j = 0; j < newEdges.length - i - 1; j++) {
                if (newEdges[j].compareTo(newEdges[j + 1]) > 0) {
                    // Swap the elements if they are out of order
                    Edge temp = newEdges[j];
                    newEdges[j] = newEdges[j + 1];
                    newEdges[j + 1] = temp;
                }
            }
        }

        edges = newEdges;
    }

    public void removeEdge(String a, String b) {
        // Check if the vertices exist in the graph
        Vertex vertexA = null;
        Vertex vertexB = null;
        for (Vertex vertex : vertices) {
            if (vertex.name.equals(a)) {
                vertexA = vertex;
            }
            if (vertex.name.equals(b)) {
                vertexB = vertex;
            }
        }

        // If either vertex is missing, do nothing
        if (vertexA == null || vertexB == null) {
            return;
        }

        // Find the edge to remove and update the edges array
        boolean edgeRemoved = false;
        Edge[] newEdges = new Edge[edges.length - 1];
        int newIndex = 0;

        for (Edge edge : edges) {
            if ((edge.vertexA == vertexA && edge.vertexB == vertexB) ||
                    (edge.vertexA == vertexB && edge.vertexB == vertexA)) {
                edgeRemoved = true;
            } else {
                newEdges[newIndex] = edge;
                newIndex++;
            }
        }

        // If the edge was removed, update the edges array
        if (edgeRemoved) {
            edges = newEdges;
        }
    }

    // public int[][] unionFind() {
    // int[] root = new int[vertices.length];
    // int[] next = new int[vertices.length];
    // int[] length = new int[vertices.length];
    // int[] result = new int[vertices.length];

    // // Initialize root, next, length, and result arrays
    // for (int i = 0; i < vertices.length; i++) {
    // root[i] = i;
    // next[i] = i;
    // length[i] = 1;
    // result[i] = 0;
    // }

    // // Perform union-find cycle detection algorithm
    // for (Edge edge : edges) {
    // int rootA = findRoot(root, edge.vertexA);
    // int rootB = findRoot(root, edge.vertexB);

    // if (rootA == rootB) {
    // // Cycle detected
    // result[rootA] = 1;
    // } else {
    // if (length[rootA] >= length[rootB]) {
    // // Merge rootB into rootA
    // next[rootB] = rootA;
    // length[rootA] += length[rootB];
    // root[rootB] = rootA;
    // } else {
    // // Merge rootA into rootB
    // next[rootA] = rootB;
    // length[rootB] += length[rootA];
    // root[rootA] = rootB;
    // }
    // }
    // }

    // // Construct the 2D array to be returned
    // int[][] unionFindResult = new int[4][vertices.length];
    // unionFindResult[0] = root;
    // unionFindResult[1] = next;
    // unionFindResult[2] = length;
    // unionFindResult[3] = result;

    // return unionFindResult;
    // }
    public int[][] unionFind() {
        int[] root = new int[vertices.length];
        int[] next = new int[vertices.length];
        int[] length = new int[vertices.length];
        int[] result = new int[vertices.length];

        for (int i = 0; i < vertices.length; i++) {
            root[i] = i;
            next[i] = i;
            length[i] = 1;
            result[i] = 0;
        }

        for (Edge edge : edges) {
            int rootA = findRoot(root, edge.vertexA);
            int rootB = findRoot(root, edge.vertexB);

            if (rootA != rootB) {
                if (length[rootA] < length[rootB]) {
                    root[rootA] = rootB;
                    length[rootB] += length[rootA];
                    next[rootA] = rootB;
                } else {
                    root[rootB] = rootA;
                    length[rootA] += length[rootB];
                    next[rootB] = rootA;
                }
            } else {
                result[edge.vertexA.getIndex()] = 1;
                result[edge.vertexB.getIndex()] = 1;
            }
        }

        int[][] unionFind = new int[4][vertices.length];
        unionFind[0] = root;
        unionFind[1] = next;
        unionFind[2] = length;
        unionFind[3] = result;

        return unionFind;
    }

    private int findRoot(int[] root, Vertex vertex) {
        int vertexIndex = -1;
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].compareTo(vertex) == 0) {
                vertexIndex = i;
                break;
            }
        }
        if (vertexIndex == -1) {
            return -1;
        }

        while (vertexIndex != root[vertexIndex]) {
            vertexIndex = root[vertexIndex];
        }

        return vertexIndex;
    }

    public boolean cycle() {
        int[] root = new int[vertices.length];
        int[] next = new int[vertices.length];
        int[] length = new int[vertices.length];

        // Initialize root, next, and length arrays
        for (int i = 0; i < vertices.length; i++) {
            root[i] = i;
            next[i] = i;
            length[i] = 1;
        }

        // Perform union-find cycle detection algorithm
        for (Edge edge : edges) {
            int rootA = findRoot(root, edge.vertexA);
            int rootB = findRoot(root, edge.vertexB);

            if (rootA == rootB) {
                // Cycle detected
                return true;
            } else {
                if (length[rootA] >= length[rootB]) {
                    // Merge rootB into rootA
                    next[rootB] = rootA;
                    length[rootA] += length[rootB];
                    root[rootB] = rootA;
                } else {
                    // Merge rootA into rootB
                    next[rootA] = rootB;
                    length[rootB] += length[rootA];
                    root[rootA] = rootB;
                }
            }
        }

        // No cycle detected
        return false;
    }

    public Graph minSpanningTree() {
        // Sort the edges in ascending order based on weights (Bubble Sort)
        for (int i = 0; i < edges.length - 1; i++) {
            for (int j = 0; j < edges.length - i - 1; j++) {
                if (edges[j].compareTo(edges[j + 1]) > 0) {
                    // Swap edges[j] and edges[j+1]
                    Edge temp = edges[j];
                    edges[j] = edges[j + 1];
                    edges[j + 1] = temp;
                }
            }
        }

        Graph minimumSpanningTree = new Graph();

        int[] parent = new int[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            minimumSpanningTree.addVertex(vertices[i].name);
            parent[i] = i;
        }

        for (Edge edge : edges) {
            int rootA = findRoot(parent, edge.vertexA);
            int rootB = findRoot(parent, edge.vertexB);

            if (rootA != rootB) {
                minimumSpanningTree.addEdge(edge.vertexA.name, edge.vertexB.name, edge.weight);
                parent[rootB] = rootA;
            }
        }

        return minimumSpanningTree;
    }

    public Vertex[][] brelazColouring() {
        int maxColor = 0;
        Vertex[][] colorMatrix = new Vertex[vertices.length][];
        int[] vertexColors = new int[vertices.length];

        // Sort the vertices array alphabetically
        sortVerticesByName();

        for (int i = 0; i < vertices.length; i++) {
            Vertex vertex = vertices[i];
            int color = 0;
            boolean isColorAvailable = false;

            // Find the lowest available color for the current vertex
            while (!isColorAvailable) {
                isColorAvailable = true;
                for (int j = 0; j < i; j++) {
                    if (hasEdgeBetweenVertices(vertex, vertices[j]) && vertexColors[j] == color) {
                        isColorAvailable = false;
                        break;
                    }
                }
                if (!isColorAvailable) {
                    color++;
                }
            }

            vertexColors[i] = color;
            maxColor = Math.max(maxColor, color);

            // Add the vertex to the corresponding color row in the colorMatrix
            if (colorMatrix[color] == null) {
                colorMatrix[color] = new Vertex[] { vertex };
            } else {
                int size = colorMatrix[color].length;
                Vertex[] newColorRow = new Vertex[size + 1];
                System.arraycopy(colorMatrix[color], 0, newColorRow, 0, size);
                newColorRow[size] = vertex;
                colorMatrix[color] = newColorRow;
            }
        }

        // Trim the colorMatrix to remove unused rows
        // return Arrays.copyOf(colorMatrix, maxColor + 1);
        Vertex[][] trimmedColorMatrix = new Vertex[maxColor + 1][];
        for (int i = 0; i < maxColor + 1; i++) {
            trimmedColorMatrix[i] = colorMatrix[i];
        }
        return trimmedColorMatrix;

    }

    private void sortVerticesByName() {
        for (int i = 0; i < vertices.length - 1; i++) {
            for (int j = i + 1; j < vertices.length; j++) {
                if (vertices[i].name.compareTo(vertices[j].name) > 0) {
                    Vertex temp = vertices[i];
                    vertices[i] = vertices[j];
                    vertices[j] = temp;
                }
            }
        }
    }

    private boolean hasEdgeBetweenVertices(Vertex vertexA, Vertex vertexB) {
        for (Edge edge : edges) {
            if ((edge.vertexA.equals(vertexA) && edge.vertexB.equals(vertexB)) ||
                    (edge.vertexA.equals(vertexB) && edge.vertexB.equals(vertexA))) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Append the vertex names as the first row with tabs
        sb.append("\t");
        for (Vertex v : vertices) {
            sb.append(v.name).append("\t");
        }
        sb.append("\n");

        // Append the adjacency matrix rows
        for (Vertex v1 : vertices) {
            sb.append(v1.name).append("\t");
            for (Vertex v2 : vertices) {
                boolean foundEdge = false;
                for (Edge e : edges) {
                    if ((e.vertexA == v1 && e.vertexB == v2) || (e.vertexA == v2 && e.vertexB == v1)) {
                        sb.append(e.weight).append("\t");
                        foundEdge = true;
                        break;
                    }
                }
                if (!foundEdge) {
                    sb.append("0\t");
                }
            }
            sb.append("\n");
        }

        return sb.toString();
    }

}
